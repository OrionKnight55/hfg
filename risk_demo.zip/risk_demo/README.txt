LOCAL HUMANITARIAN RISK DEMO

Double-click index.html to view in a browser. No installation or internet needed.

VS Code: File > Open Folder > select this risk_demo folder. Open index.html to edit. To view it, right-click index.html in Windows Explorer and Open with your browser. The optional VS Code Live Server extension also works, but is not required.

The page embeds a snapshot of the 139 prepared draft topics. It does not save reviews, publish topics, or update the original data. AI content is selective and requires full moderator review. ACAPS ratings are copied from the export; status is not verified as current.

The probability axis is ordinal, not a percentage. Missing probability or impact results in an unavailable chart.

To integrate with the existing website, use the separately supplied risk_topics.json and schema. This self-contained demo is only a visual prototype.

VERIFICATION
JavaScript syntax and programmatic render/interaction checks passed for all 139 topics, including 125 chart markers and 14 missing-data states. A live visual browser review could not be completed because local network access and desktop browser automation were unavailable.
